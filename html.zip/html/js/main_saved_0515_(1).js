$(document).ready(function(){
    // 스크롤시 헤더 변화
    $(function(){
        $(window).scroll(function(){
            if($(window).scrollTop() >= 80){
                $("#header").addClass("on");
            }
            else {
                $("#header").removeClass("on");
            }
        })

        if($(window).scrollTop() >= 80){
            $("#header").addClass("on");
        }
        else {
            $("#header").removeClass("on");
        }
    })

    $("#header .gnb .right_box li.no_hide a").click(function(){
        $(this).parent().toggleClass("on");
        $("#header .search_box").toggleClass("on");
        return false;
    })

    // 햄버거 버튼 클릭 - 메뉴 활성화
    $(".m_btn").click(function(){
        $("html").toggleClass("lock");
        $(this).toggleClass("on");
        $(".mobile_screen").stop().fadeIn().addClass("active")
        if(!$(this).hasClass("on")){
            $(".mobile_screen").stop().fadeOut().removeClass("active");
        }
    })

    // 배경 및 닫기버튼 - 메뉴 비활성화
    $(".mobile_screen .bg").click(function(){
        $(".m_btn").trigger("click");
    })

    // 메인 스티커 세로
    // if($("#main04 .lat_box").children("li").length > 4){
    //     $("#main04 .lat_box").eq(0).css("height",($(".lat_box").children("li").outerHeight() + 10) * 2)
    // }

    // 메인 카테고리 클릭 스티커
    $("#main04 .cate_list li a").on("click",function(){
        $(this).parent().addClass("active").siblings().removeClass("active");
        $("#main04 .lat_wrap .lat_box").eq($(this).parent().index()).addClass("active").siblings().removeClass("active");
        return false;
    })

    /***************************** 상품 상세 스텝 *****************************/
    
    // 상품 - 다음 단계 클릭
    $("#sit_ov_btn .next_step").click(function(){
        // 사이즈 선택
        if(!$("input[name='ct_memo1']").is(":checked")){
            alert("사이즈를 선택해주세요");
            return false;
        }

        // 사이즈 수치 선택
        if($("input[value='ONE SIZE']").is(":checked")){
            if(!$("input[name='ct_memo2']").is(":checked")){
                alert("사이즈를 선택해주세요");
                return false;
            }
        }

        $("html").css("overflow","hidden")
        $("#model_pop").fadeIn(300);
    })

    // 체형 닫기
    $("#model_pop .sel_model .close_btn, #model_pop > .bg").click(function(){
        $("html").css("overflow", "auto");
        $("#model_pop").fadeOut(300);
    })

    // 체형 선택 -> 프리뷰
    $("#model_pop .sel_box button").click(function(){
        $(".preview_model").fadeIn(300);
        $(".preview_model").css("display","flex");
    })

    // 프리뷰 닫기
    $("#model_pop .preview_model .close_btn, #model_pop .preview_model .bg").click(function(){
        $(".preview_model").fadeOut(300);
    })

    /***************************************************************************/

    const top_bar = new Swiper(".top_bar", {
        loop : true,
        speed : 550,
        autoplay : {
            delay : 3000,
            disableOnInteraction : false,
        },
        direction : "vertical",
        allowTouchMove: false,
    })

    const visual_slide = new Swiper(".visual_slide",{
        loop : true,
        //allowTouchMove:false,
        speed:750,
        /*autoplay : {
            delay : 3000,
            disableOnInteraction : false,
        },*/
    })

    const preview_slide = new Swiper(".preview_slide",{
        pagination: {
          el: ".preview_pagination",
          clickable: true,
        },
        navigation: {
            nextEl: ".preview_slide .next_btn",
            prevEl: ".preview_slide .prev_btn",
        },
    })
})