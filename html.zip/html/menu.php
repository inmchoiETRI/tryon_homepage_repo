<?php
    $menu_datas = get_menu_db(0, true);
    $i = 0;
    foreach( $menu_datas as $row ){
        if( empty($row) ) continue;
        $add_class = (isset($row['sub']) && $row['sub']) ? 'gnb_al_li_plus' : '';
    ?>
    <li>
        <a href="<?php echo $row['me_link']; ?>" target="_<?php echo $row['me_target']; ?>" <?=(isset($row['sub']) && $row['sub']) ? "class=\"more_depth\"" : ""?>>
            <?php echo $row['me_name'] ?>
            <?=(isset($row['sub']) && $row['sub']) ? "<i class=\"xi-angle-down\"></i>" : ""?>
        </a>
        <?php
        $k = 0;
        foreach( (array) $row['sub'] as $row2 ){

            if( empty($row2) ) continue; 

            if($k == 0)
                echo '<ul class="depth02">'.PHP_EOL;
        ?>
            <li><a href="<?php echo $row2['me_link']; ?>" target="_<?php echo $row2['me_target']; ?>"><?php echo $row2['me_name'] ?></a></li>
        <?php
        $k++;
        }   //end foreach $row2

        if($k > 0)
            echo '</ul>'.PHP_EOL;
        ?>
    </li>
    <?php
    $i++;
    }   //end foreach $row

    if ($i == 0) {  ?>
        <li class="gnb_empty">메뉴 준비 중입니다.<?php if ($is_admin) { ?> <a href="<?php echo G5_ADMIN_URL; ?>/menu_list.php">관리자모드 &gt; 환경설정 &gt; 메뉴설정</a>에서 설정하실 수 있습니다.<?php } ?></li>
<?php } ?>