<?php 
    include_once("../common.php");
    include_once(G5_THEME_SHOP_PATH."/shop.head.php");
?>

<style>
    #header, #footer {display: none;}
    #wrap.sub_wrap {margin-top:0;}

    
.in_style_pop {min-width: 1300px; display: flex; flex-wrap: wrap; padding:0 50px;}
.in_style_pop .cont_box > strong {display: block; font-size: 1.125rem; font-weight: 500; letter-spacing: 0.1em; margin-bottom: 30px;}
.in_style_pop .left_box {width: 31%; display: flex; flex-wrap: wrap; justify-content: space-between; padding-bottom: 25px;}
.in_style_pop .right_box {width: 67%; display: flex; flex-wrap: wrap; justify-content: space-between;}

.in_style_pop .left_box .box1 {width: 52%;}
.in_style_pop .left_box .box2 {width: 35%;}

.in_style_pop .right_box .box1 {width: 67%; display: flex; justify-content: center; align-items: flex-end; position:relative;}
.in_style_pop .right_box .box2 {width: 22%; display: flex; flex-direction: column; justify-content: flex-end; margin-bottom: 50px;;}

.in_style_pop .left_box .box1 #select_co {width: 100%; border:1px solid #9f9f9f; font-size: 0.9375rem; font-weight: 500; text-align: center; padding:18px 0; letter-spacing: 0.1em; cursor: pointer; margin-bottom: 40px; margin-top:50px;}
.in_style_pop .left_box .box1 .about_co strong {margin-bottom: 15px;}
.in_style_pop .left_box .box1 .about_co p {height: 165px; font-size: 0.875rem; line-height: 1.7; letter-spacing: -0.05em; padding-right: 10px; overflow: auto;}
.in_style_pop .left_box .box1 .cont_box:nth-of-type(2) {margin:50px 0;}
.in_style_pop .left_box .box1 .select_color {display: flex;}
.in_style_pop .left_box .box1 .select_color li:not(:nth-child(4n)) {margin-right: 5.5%;}
.in_style_pop .left_box .box1 .select_color input[type="radio"] {display: none;}
.in_style_pop .left_box .box1 .select_color label {display: block; width: 3.125vw; min-width: 45px; height: 3.125vw; min-height: 45px; border-radius: 100%; cursor: pointer;}
.in_style_pop .left_box .box1 .select_color label.white {border:1px solid #d1d1d1;}
.in_style_pop .left_box .box1 .select_color label.gray {background:#d1d1d1;}
.in_style_pop .left_box .box1 .select_color label.orange {background:#cc6d10;}
.in_style_pop .left_box .box1 .select_color label.black {background:#242424;}
.in_style_pop .left_box .box1 .select_color input[type="radio"]:checked + label {border:3px solid #fff; outline:3px solid #000;}
.in_style_pop .left_box .box1 .select_model {border:1px solid #9f9f9f; position:relative; overflow: hidden;}
.in_style_pop .left_box .box1 .select_model li {text-align: center;}
.in_style_pop .left_box .box1 .select_model li img {max-width: 100%;}
.in_style_pop .left_box .box1 .select_model .model_btn {width: 95%; position:absolute; top:50%; left:2.5%; z-index: 2;}
.in_style_pop .left_box .box1 .select_model .model_btn button {font-size: 1.75rem; transform:translateY(-50%)}
.in_style_pop .left_box .box1 .select_model .model_btn .prev_btn {position:absolute; left:0;}
.in_style_pop .left_box .box1 .select_model .model_btn .next_btn {position:absolute; right:0;}
.in_style_pop .left_box .box2 {margin-top:187px}
.in_style_pop .left_box .box2 ul {height: 775px; padding-right: 15px; overflow: auto;}
.in_style_pop .left_box .box2 ul li {height: 140px; border:1px solid #9f9f9f; background:#fff;}
.in_style_pop .left_box .box2 ul li:not(:last-child) {margin-bottom: 15px;}
.in_style_pop .left_box .box2 ul li a {display: flex; justify-content: center; align-items: center; width: 100%; height: 100%; padding:20px;}
.in_style_pop .left_box .box2 ul li img {max-width: 100%; max-height: 100%;}
.in_style_pop .right_box .box1 .large_model img {max-width: 85%;}
.in_style_pop .right_box .box1 .large_control {display: flex; align-items: center; position:absolute; left:45%; bottom:35px; transform:translateX(-50%)}
.in_style_pop .right_box .box1 .large_control button {display: flex; justify-content: center; align-items: center; width: 50px; height: 50px; background:#fff; border-radius: 100%; font-size: 1.125rem;}
.in_style_pop .right_box .box1 .large_control button:nth-child(2) {width: 65px; height: 65px; margin:0 30px;}
.in_style_pop .right_box .box1 .large_control button i {font-weight: 900;}
.in_style_pop .right_box .box1 .large_control button:hover {color:#fff; background:#000;}
.in_style_pop .right_box .box2 button {width: 100%; padding:25px 0; border:1px solid #000; font-size: 1.25rem; letter-spacing: -0.025em;}
.in_style_pop .right_box .box2 .buy_btn {color:#fff; background:#000; margin-top:20px;}

.in_style_pop .left_box .box1 .about_co p::-webkit-scrollbar,
.in_style_pop .left_box .box2 ul::-webkit-scrollbar {width: 10px;}

.in_style_pop .left_box .box1 .about_co p::-webkit-scrollbar-thumb,
.in_style_pop .left_box .box2 ul::-webkit-scrollbar-thumb {background:#3e3e3e; border-radius: 150px;}

.in_style_pop .left_box .box1 .about_co p::-webkit-scrollbar-track,
.in_style_pop .left_box .box2 ul::-webkit-scrollbar-track {background:#eee; border-radius: 150px;}
</style>

<div class="in_style_pop">
    <div class="left_box">
        <div class="box1">
            <select name="" id="select_co">
                <option value="">SLEEPY</option>
                <option value="">JONNY</option>
                <option value="">LEEKO J</option>
                <option value="">NICHOLAS KIRKWOOD</option>
            </select>
            <div class="cont_box about_co">
                <strong>NICHOLAS KIRKWOOD</strong>
                <p>
                    "커크우드는 영국 패션 어워드에서 올해의 액세서리 디자이너로 3번 선정되었으며, 2013년에는 영국 패션 위원회/보그 디자이너 패션 기금 상을 수상한 최초의 액세서리 디자이너가 되었습니다.
                    가상 상품 분야에 대한 이 새로운 모험에 따라, Kirkwood는 최근 2022년 3월에 Debocaland의 첫 메타버스 패션 위크에서 가상 팝업 스토어를 디자인한 전설적 인 NFT White Rabbit 집단과 협력합니다.
                    White Rabbit NFT 컬렉션은 화이트 래빗 캐릭터를 둘러싼 서술적 유산을 이어가려는 의도로 제작은 《Through The Looking Glass》와 《The Matrix》에서 처음 소개되었다.
                    '화이트래빗'은 보유자 모두가 GATE 생태계를 통해 NFT의 토끼굴을 탐험할 수 있도록 안내하기 위해 마련된 토큰이다.
                </p>
            </div>
            <div class="cont_box">
                <strong>SELECT COLOR</strong>
                <ul class="select_color">
                <li>
                    <input type="radio" value="white" id="color01" name="color">
                    <label for="color01" class="white"></label>
                </li>
                <li>
                    <input type="radio" value="gray" id="color02" name="color">
                    <label for="color02" class="gray"></label>
                </li>
                <li>
                    <input type="radio" value="orange" id="color03" name="color">
                    <label for="color03" class="orange"></label>
                </li>
                <li>
                    <input type="radio" value="black" id="color04" name="color">
                    <label for="color04" class="black"></label>
                </li>
                </ul>
            </div>
            <div class="cont_box">
                <strong>SELECT MODEL</strong>
                <div class="select_model">
                    <ul class="swiper-wrapper">
                        <li class="swiper-slide"><img src="<?=G5_IMG_URL?>/sel_model1.png" alt=""></li>
                        <li class="swiper-slide"><img src="<?=G5_IMG_URL?>/sel_model2.png" alt=""></li>
                        <li class="swiper-slide"><img src="<?=G5_IMG_URL?>/sel_model3.png" alt=""></li>
                    </ul>
                    <div class="model_btn">
                        <button class="prev_btn"><i class="xi-angle-left-thin"></i></button>
                        <button class="next_btn"><i class="xi-angle-right-thin"></i></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="box2">
            <ul class="sticker_list">
                <li><a href="#"><img src="<?=G5_IMG_URL?>/sticker01.png" alt=""></a></li>
                <li><a href="#"><img src="<?=G5_IMG_URL?>/sticker02.png" alt=""></a></li>
                <li><a href="#"><img src="<?=G5_IMG_URL?>/sticker03.png" alt=""></a></li>
                <li><a href="#"><img src="<?=G5_IMG_URL?>/sticker04.png" alt=""></a></li>
                <li><a href="#"><img src="<?=G5_IMG_URL?>/sticker05.png" alt=""></a></li>
                <li><a href="#"><img src="<?=G5_IMG_URL?>/sticker06.png" alt=""></a></li>
                <li><a href="#"><img src="<?=G5_IMG_URL?>/sticker07.png" alt=""></a></li>
            </ul>
        </div>
    </div>
    <div class="right_box">
        <div class="box1">
            <div class="large_model">
                <img src="<?=G5_IMG_URL?>/large_model.png" alt="">
            </div>
            <div class="large_control">
                <button class="turn_l"><i class="xi-angle-left"></i></button>
                <button class="close_btn"><i class="xi-close"></i></button>
                <button class="turn_r"><i class="xi-angle-right"></i></button>
            </div>
        </div>
        <div class="box2">
            <button class="apply_btn">APPLY</button>
            <button class="buy_btn">BUY NOW</button>
        </div>
    </div>
</div>

<script>
    const sel_model = new Swiper(".select_model", {
        loop:true,
        navigation: {
            nextEl: ".model_btn .next_btn",
            prevEl: ".model_btn .prev_btn",
        },
    })
</script>

<?php include_once(G5_THEME_SHOP_PATH."/shop.tail.php");?>